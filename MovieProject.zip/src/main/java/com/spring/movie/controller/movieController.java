package com.spring.movie.controller;

public class movieController {
	
}
